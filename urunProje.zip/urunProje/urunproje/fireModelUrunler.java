package com.urunproje.urunproje;

public class fireModelUrunler {

    public String market;
    public String stok;

    public String getMarket() {
        return market;
    }

    public void setMarket(String market) {
        this.market = market;
    }

    public String getStok() {
        return stok;
    }

    public void setStok(String stok) {
        this.stok = stok;
    }

    public String getUrunAdi() {
        return urunAdi;
    }

    public void setUrunAdi(String urunAdi) {
        this.urunAdi = urunAdi;
    }

    public String getUrunFiyat() {
        return urunFiyat;
    }

    public void setUrunFiyat(String urunFiyat) {
        this.urunFiyat = urunFiyat;
    }

    public String getUrunFiyatTarihi() {
        return urunFiyatTarihi;
    }

    public void setUrunFiyatTarihi(String urunFiyatTarihi) {
        this.urunFiyatTarihi = urunFiyatTarihi;
    }

    public String getUrunID() {
        return urunID;
    }

    public void setUrunID(String urunID) {
        this.urunID = urunID;
    }

    public String urunAdi;
    public String urunFiyat;
    public String urunFiyatTarihi;
    public String urunID;


}
